package com.example.flask_flutter_demo_v3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
